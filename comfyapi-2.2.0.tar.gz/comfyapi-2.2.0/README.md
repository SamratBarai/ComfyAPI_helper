# ComfyAPI Client

A Python client library for interacting with a running ComfyUI instance via its API. Allows you to programmatically queue workflows, monitor progress, and retrieve outputs.

## Features

*   Load ComfyUI workflow JSON files.
*   Edit workflow parameters (prompts, seeds, dimensions, etc.) programmatically.
*   Submit single or batch workflows for execution.
*   Wait for job completion (single or batch) with non-blocking polling.
*   Retrieve output image URLs and download outputs.
*   Designed for automation, scripting, and integration with UIs (e.g., Gradio, Flask).

## Installation

```bash
pip install comfyapi # Or: pip install . if installing from local source
```

**Dependencies:**

*   `requests`
*   `websocket-client`
*   `Pillow` (optional, required for automatic image resizing)

These will be installed automatically via pip (install `Pillow` if you plan to use image upload/resize features).

## Usage

### Recommended: ComfyAPIManager (Single & Batch)

```python
from comfyapi import ComfyAPIManager
import time

manager = ComfyAPIManager()
manager.set_base_url("http://127.0.0.1:8188")
manager.load_workflow("path/to/your/workflow.json")

# Edit workflow parameters (example: prompt and seed)
manager.edit_workflow(["6", "inputs", "text"], "a beautiful landscape painting")
manager.edit_workflow(["3", "inputs", "seed"], 123456)

# Submit workflow
prompt_id = manager.submit_workflow()

# Wait for completion
while not manager.check_queue(prompt_id):
    print("Workflow running...")
    time.sleep(1)
print("Workflow finished!")

# Retrieve and download output
output_url, filename = manager.find_output(prompt_id, with_filename=True)
manager.download_output(output_url, save_path="output_images", filename=filename)
```

### Batch Example (Multiple Images, Automatic Seeds)

```python
# Number of images to generate
num_images = 5
# Path to the seed input in your workflow (update as needed)
seed_node_path = ["3", "inputs", "seed"]

uids = manager.batch_submit(num_seeds=num_images, seed_node_path=seed_node_path)
print(f"Batch submitted. Prompt IDs: {uids}")

# Wait for all jobs to finish
pending = set(uids)
results = {}
while pending:
    finished = []
    for uid in list(pending):
        if manager.check_queue(uid):
            output_url, filename = manager.find_output(uid, with_filename=True)
            results[uid] = (output_url, filename)
            print(f"Prompt {uid} finished! Output: {filename}")
            finished.append(uid)
    for uid in finished:
        pending.remove(uid)
    if pending:
        print(f"Waiting for {len(pending)} jobs...")
        time.sleep(1)

# Download all outputs
for uid, (output_url, filename) in results.items():
    print(f"Downloading {filename} from {output_url}")
    manager.download_output(output_url, save_path="batch_output", filename=filename)
    print(f"Downloaded {filename}")
print("All downloads complete.")

### Image Uploads (Base64) 🔧

To inject local images into a workflow using the **Base64ImageLoader** node, clone the helper nodes into your ComfyUI `custom_nodes` folder and restart ComfyUI:

```bash
# Example (replace with your ComfyUI custom_nodes path)
git clone https://github.com/SamratBarai/ComfyAPI_helper <COMFYUI_CUSTOM_NODES_DIR>/ComfyAPI_helper
```

After the helper nodes are available, you can encode and inject an image directly into your workflow using `ComfyAPIManager.set_base64_image`:

```python
# Example: node id '10' in examples/workflw.json is a Base64ImageLoader
# The method will automatically downscale/recompress large images (default max 1MB and 1024px max dimension).
# You can tune behavior with optional parameters `max_size_bytes` and `max_dimension`.
manager.set_base64_image(node_id="10", image_path="examples/example.png")
# Or specify limits explicitly:
manager.set_base64_image(node_id="10", image_path="examples/example.png", max_size_bytes=300000, max_dimension=800)
```

The supplied example workflow `examples/workflw.json` includes a `Base64ImageLoader` node (id `10`) configured to accept `image_base64`, `image_name`, and `image_path` inputs. Restart ComfyUI after adding custom nodes so the new node types are registered.

Note: When large images are resized they are typically recompressed to JPEG to reduce payload size; this will flatten transparency (alpha channel) to a white background and the `image_name` may use a `.jpg` extension after processing.

---

```

### Legacy API (Functional, Not Recommended)

```python
import comfyapi

comfyapi.set_base_url("http://127.0.0.1:8188")
workflow = comfyapi.load_workflow("path/to/your/workflow.json")
workflow = comfyapi.edit_workflow(workflow, ["6", "inputs", "text"], "a beautiful landscape painting")
workflow = comfyapi.edit_workflow(workflow, ["3", "inputs", "seed"], 12345)

prompt_id = comfyapi.submit(workflow)
filename, output_url = comfyapi.wait_for_finish(prompt_id)
comfyapi.download_output(output_url, save_path="output_images")
```

## API Reference (Key Methods)

### ComfyAPIManager
- `set_base_url(url)`
- `load_workflow(filepath)`
- `edit_workflow(path, value)`
- `submit_workflow()`
- `batch_submit(num_seeds=None, seeds=None, seed_node_path=[...])`
- `check_queue(prompt_id)`
- `find_output(prompt_id, with_filename=False)`
- `wait_for_finish(prompt_id, poll_interval=3, max_wait_time=600, status_callback=None)`
- `wait_and_get_all_outputs(uids, status_callback=None)`
- `download_output(output_url, save_path=".", filename=None)`
- `set_base64_image(node_id, image_path, temp_name=None)`

### Exceptions
- `ComfyAPIError`, `ConnectionError`, `QueueError`, `HistoryError`, `ExecutionError`, `TimeoutError`

## Notes
- Always update the seed node path based on your workflow structure.
- All editing is non-destructive: the workflow is copied and updated in memory.
- Use the Manager for all new scripts and integrations.

## Contributing

*(TODO: Add contribution guidelines)*

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
